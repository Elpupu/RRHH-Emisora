package com.umcc.rhemisora.repository;

import com.umcc.rhemisora.entity.MunicipioEntity;

public interface IMunicipioRepository extends IBaseRepository<MunicipioEntity, String>{
}
