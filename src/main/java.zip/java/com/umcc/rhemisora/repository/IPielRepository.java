package com.umcc.rhemisora.repository;

import com.umcc.rhemisora.entity.PielEntity;

public interface IPielRepository extends IBaseRepository<PielEntity, String> {
}
