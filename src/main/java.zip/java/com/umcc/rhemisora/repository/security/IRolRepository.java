package com.umcc.rhemisora.repository.security;

import com.umcc.rhemisora.entity.security.RolEntity;
import com.umcc.rhemisora.repository.IBaseRepository;

public interface IRolRepository extends IBaseRepository<RolEntity, String> {
}
