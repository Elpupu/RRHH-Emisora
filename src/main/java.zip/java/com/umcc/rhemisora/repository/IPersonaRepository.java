package com.umcc.rhemisora.repository;

import com.umcc.rhemisora.entity.PersonaEntity;

public interface IPersonaRepository extends IBaseRepository<PersonaEntity, String>{
}
