package com.umcc.rhemisora.repository;

import com.umcc.rhemisora.entity.Nivel_EscolaridadEntity;

public interface INivel_EscolaridadRepository extends IBaseRepository<Nivel_EscolaridadEntity, String> {
}
