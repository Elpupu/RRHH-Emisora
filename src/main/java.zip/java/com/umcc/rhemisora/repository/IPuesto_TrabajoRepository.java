package com.umcc.rhemisora.repository;

import com.umcc.rhemisora.entity.Puesto_TrabajoEntity;

public interface IPuesto_TrabajoRepository extends IBaseRepository<Puesto_TrabajoEntity, String>{
}
