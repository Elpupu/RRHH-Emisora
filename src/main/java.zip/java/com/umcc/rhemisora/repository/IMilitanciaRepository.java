package com.umcc.rhemisora.repository;

import com.umcc.rhemisora.entity.MilitanciaEntity;

public interface IMilitanciaRepository extends IBaseRepository<MilitanciaEntity, String> {
}
