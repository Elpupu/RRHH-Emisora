package com.umcc.rhemisora.service.security;

import com.umcc.rhemisora.model.security.RolModel;
import com.umcc.rhemisora.service.IBaseService;

public interface IRolService extends IBaseService<RolModel, String> {
}
