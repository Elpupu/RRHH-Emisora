package com.umcc.rhemisora.service;

import com.umcc.rhemisora.model.Nivel_EscolaridadModel;

public interface INivel_EscolaridadService extends IBaseService<Nivel_EscolaridadModel, String> {
}
