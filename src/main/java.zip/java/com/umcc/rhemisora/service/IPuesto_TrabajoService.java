package com.umcc.rhemisora.service;

import com.umcc.rhemisora.model.Puesto_TrabajoModel;

public interface IPuesto_TrabajoService extends IBaseService<Puesto_TrabajoModel, String>{
}
