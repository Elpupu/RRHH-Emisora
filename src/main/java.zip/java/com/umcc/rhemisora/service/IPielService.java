package com.umcc.rhemisora.service;

import com.umcc.rhemisora.model.PielModel;

public interface IPielService extends IBaseService<PielModel, String>{
}
