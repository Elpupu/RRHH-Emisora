package com.umcc.rhemisora.service;

import com.umcc.rhemisora.model.MunicipioModel;

public interface IMunicipioService extends IBaseService<MunicipioModel, String>{
}
