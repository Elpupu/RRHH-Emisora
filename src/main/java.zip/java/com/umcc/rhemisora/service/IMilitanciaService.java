package com.umcc.rhemisora.service;

import com.umcc.rhemisora.model.MilitanciaModel;

public interface IMilitanciaService extends IBaseService<MilitanciaModel, String>{
}
