package com.umcc.rhemisora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication()
public class RhEmisoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(RhEmisoraApplication.class, args);
	}

}
